star  C:\Oracle\PPI-2024-2\scripts\schema.sql
star C:\Oracle\PPI-2024-2\scripts\tablas.sql
star C:\Oracle\PPI-2024-2\scripts\reglas.sql

